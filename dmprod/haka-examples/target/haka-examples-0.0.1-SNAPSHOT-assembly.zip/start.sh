#!/bin/bash

java -cp ./haka-examples.jar:./lib/* com.persinity.haka.example.ExampleRunner $@


